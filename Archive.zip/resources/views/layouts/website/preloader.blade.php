<div class="preloader">
    <div class="preloader__imges">
        <img src="{{asset('assets/images/frontend/preloader/632ebf9b581241664008091.png')}}"
            class="preloader__img one" alt="No Image">
        <img src="{{asset('assets/images/frontend/preloader/632ebf9b5e2681664008091.png')}}"
            class="preloader__img two" alt="No Image">
    </div>
</div>